import core.implant

class ExecCmdImplant(core.implant.Implant):
    pass
